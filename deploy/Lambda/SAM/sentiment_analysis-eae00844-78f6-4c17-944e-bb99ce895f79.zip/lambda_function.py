import json

import nltk
import nltk.classify.util
from nltk.classify import NaiveBayesClassifier
from nltk.corpus import movie_reviews

nltk.data.path.append("/tmp")
nltk.download("movie_reviews", download_dir = "/tmp")

import string

import pickle

import sys

import boto3

import os

import subprocess


def lambda_handler(event, context):
    
    # classify a sample input sentence to positive / negative class and give the probability of
    # belonging to each class, based on trained model

    def classify_text(text):
        tokenized_text = tokenizer(text)
        featured_text = word_feats(tokenized_text)
        sentiment = classifier_from_disk.classify(featured_text)
        sentiment_prob = classifier_from_disk.prob_classify(featured_text)
        return sentiment, sentiment_prob.prob('pos'), sentiment_prob.prob('neg')
        
    # converting words inside input sentence ( set of words ) to a dictionary of [word , true] to set
    # learning features

    def word_feats(words):
        return dict([(word, True) for word in words])
        
    # tokenize ( separate ) words of input text, leave out punctuations ( . , ? ! : " ' etc )
    # and change to lower case format

    def tokenizer(text):
        stops = list(string.punctuation)
        tokens = []
        for word in text:
            word.lower()
            if word not in stops:
                tokens.append(word)
        return tokens
    
    f = open('/opt/NaiveBayesClassifierTrainedModel.pickle', 'rb')
    classifier_from_disk = pickle.load(f)
    f.close()
    
    sentence = event['responsePayload']['recognized_text']
    file_name = event['responsePayload']['file_name']
    
    
    sentiment, sentiment_prob_pos, sentiment_prob_neg = classify_text(sentence)
    
    print("\n\n\n")
    print("[DEBUG] Sentence:", sentence)
    print("[DEBUG] Sentence belongs to class:", sentiment)
    print("[DEBUG] Probability of positive is :", sentiment_prob_pos)
    print("[DEBUG] Probability of negative is :", sentiment_prob_neg)
    print("\n\n\n")
    
    return {
        'statusCode': 200,
        'file_name': file_name,
        'sentence': sentence,
        'sentiment_analysis_sentiment': sentiment,
        'sentiment_analysis_sentiment_positive_probability': sentiment_prob_pos,
        'sentiment_analysis_sentiment_negative_probability': sentiment_prob_neg,
    }
